Contributors: Alexis Sanehisa + Maudeline Deus

Maudeline Deus's contributions M1:
made functions.cpp functions.h main.cpp Makefile, added base code

Alexis Sanehisa's contributions M1:
made git repo, added to Makefile, made tests.cpp, edited M's powerOfTwo func
Contributors: Alexis Sanehisa + Maudeline Deus

Maudeline Deus's contributions M1:
made functions.cpp functions.h main.cpp Makefile, added base code

Alexis Sanehisa's contributions M1:
made git repo, added to Makefile, made tests.cpp, edited M's powerOfTwo func

Maudeline Deus's contributions M2:
vectors, lots of functions in functions.cpp, write allocate / no allocate / bac\
k / through, chatted together on zoom

Alexis Sanehisa's contributions	M2:
lot of psuedocode, main, tag and index calculations, both chatted on zoom

Todo: fifo, shorten main

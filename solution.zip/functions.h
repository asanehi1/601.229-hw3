#include <iostream>

int lru();
int fifo();
int powerOfTwo(int num);